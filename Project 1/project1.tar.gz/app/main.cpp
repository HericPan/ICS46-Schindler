// If you really want to make a program for the app, be my guest.
// You may prefer to do so in /exp instead.
// Or better yet, use gtest to automate your own test cases!
// #include "proj1.hpp"
// #include <vector>
// #include "ver.hpp" 
// #include <string>
// #include <unordered_map>
// #include <iostream>
// #include <algorithm>
// using namespace std;


// void printMappings(const std::unordered_map<char, unsigned>& mapping) {
//     unsigned j = 1;
//     for (std::pair<char, unsigned> i : mapping) {
//         cout << j << "th key: " << i.first << ", value: " << i.second << std::endl;
//         j++;
//     }
// }

int main()
{
    // std::string s1 = "ABABK";
    // std::string s2 = "IIIIIIIBABAC";
    // // ABABK = 12129
    // // BABAC = 21213
    // // CCCDB = 33342
    // std::string s3 = "IIIIIIICCCDB";
    // std::vector<bool> digitalUseState(10);
    // // digitalUseState.at(1) = true;
    // // digitalUseState.at(2) = true;
    // // std::unordered_map<char, unsigned> mapping{{'A', 1},  {'C', 7},{'D', 4}, {'E', 5}, {'G' , 3}, {'F', 0}};
    // std::unordered_map<char, unsigned> mapping{};
    // // std::unordered_map<char, unsigned> mapping{};
    // // cout << search(1, currentPlace, s1,s2,s3,  carryIn,digitalUseState,  mapping) << endl;
    // puzzleSolver(s1, s2, s3, mapping);
    // printMappings(mapping);
    // // cout << gradeYesAnswer("GABA", "GBAB", "CDCCC", mapping) << endl;

    return 0;
}



